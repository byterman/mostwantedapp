import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.page.html',
  styleUrls: ['./form.page.scss'],
})
export class FormPage implements OnInit {

  name;
  alias;
  edad;
  raza;
  sexo;
  pelo;
  descripcion;
  img;
  
  addcriminal(){
    
    if(this.raza==null){
      this.raza = "";
    }
    if(this.sexo==null){
      this.sexo = "";
    }
  
    var data = new FormData();
    data.append("nombre",this.name);
    data.append("alias",this.alias);
    data.append("edad",this.edad);
    data.append("raza",this.raza);
    data.append("sexo",this.sexo);
    data.append("pelo",this.pelo);
    data.append("descripcion",this.descripcion);
    data.append("imatge",this.img);




   // console.log(data.name, data.alias, data.edad, data.raza, data.sexo, data.pelo, data.descripcion);

    this._apiSerice.addcriminal(data).subscribe((Response) =>{
      console.log(Response);
    })

  }



  selectedFile(event){
    this.img = event.target.files[0];
  }


  constructor(public _apiSerice: ApiService) {
    
   }



  ngOnInit() {
  }


 
  
}

