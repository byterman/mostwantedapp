import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.page.html',
  styleUrls: ['./lista.page.scss'],
})
export class ListaPage implements OnInit {

  criminales: any = [];

  



  constructor(public _apiService: ApiService) { 
    this.leercriminal();
  }

  ngOnInit() {
  }

  leercriminal(){
    this._apiService.readcriminal().subscribe((Response)=> {
      console.log(Response);
      this.criminales=Response;
    })
  }

  deleteCriminal(id){
    this._apiService.eliminarcriminal(id).subscribe((Response) =>{
      console.log(Response);
    })
  }

}
