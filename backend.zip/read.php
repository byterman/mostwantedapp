<?php
    include "config.php";

    $response = array();

    $query = "SELECT * FROM criminal";

    $sql = mysqli_query($con, $query);

    
    
    while($row = mysqli_fetch_object($sql)){
        $response[] = $row;
    }
    
    


    echo json_encode($response);
?>

