<?php
    include "config.php";
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    $response = array();


    $nombre = $_POST["nombre"];
    $nick = $_POST["alias"];
    $edad = $_POST["edad"];
    $raza = $_POST["raza"];
    $sexo = $_POST["sexo"];
    $pelo = $_POST["pelo"];
    $descripcion = $_POST["descripcion"];
    $imagen = $_FILES["imatge"]['name'];


    $archivo_nombreimg = substr($imagen, 0, strripos($imagen, '.'));  
    $archivo_extensionimg = substr($imagen, strripos($imagen, '.')); 

    $dir_subida = 'img/';
    
    if($archivo_extensionimg==".png"||$archivo_extensionimg=="jpg"||$archivo_extensionimg=="jpeg") {

        $milliseconds = round(microtime(true) * 1000);
        $fichero_subido = $dir_subida . basename($milliseconds.$archivo_extensionimg);
        $nombreArchiboSubirMsql = $milliseconds.$archivo_extensionimg;
    
        if (move_uploaded_file($_FILES['imatge']['tmp_name'], $fichero_subido)) {   
            echo "El fichero es válido y se subió con éxito.<br>";
        } else {    
            $nombreArchiboSubirMsql="null";
            echo "¡Error!<br>";
        }
    
    }else{
    
        echo "ERROR FORMATO ERRONEO <br>";
    
    }






    $imgtest = "preview.png";


   
    // Insert into criminal(Nombre,Alias,Edad,Raza,Sexo,Pelo,Descripcion,Foto)VALUES('$nombre','$nick',2,'$raza','$sexo','$pelo','$descripcion','$imgtest')
    $sql = mysqli_query($con, "Insert into criminal(Nombre,Alias,Edad,Raza,Sexo,Pelo,Descripcion,Foto)VALUES('".$nombre."','".$nick."',".$edad.",'". $raza."','".$sexo."','".$pelo."','".$descripcion."','".$nombreArchiboSubirMsql."')");
    if($sql){
        $response["message"] = "OK";
    }else{
        $response["message"] = "KO";
    }
    echo json_encode($response);
?>
