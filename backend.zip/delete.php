<?php
        include "config.php";
        
        $response = array();


        $id = $_POST["id"];
        $imagen = $_POST["imagen"];
      
       
    

        $sql = mysqli_query($con, "DELETE FROM criminal WHERE IDcriminal = $id"); 
        if($sql){
            $response["message"] = "OK";
        }else{
            $response["message"] = "KO";
        }


        if (!unlink("img/".$imagen)) { 
            $response["message"] =  $imagen." no se ha eliminado"; 
        } 
        else { 
            $response["message"] =  $imagen." se elimino junto al contenido de la tabla"; 
        } 

        echo json_encode($response);






?>
